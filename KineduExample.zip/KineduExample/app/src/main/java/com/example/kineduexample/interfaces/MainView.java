package com.example.kineduexample.interfaces;

import com.example.kineduexample.entities.DataActivities;

import java.util.List;

public interface MainView {
    void updateUI(DataActivities activities);
}
